MIDTERM 151 - Bootstrap 網頁作業

內容：
- index.html：網頁首頁
- assets/slide-1.svg 至 slide-4.svg：四張 1280 x 500 輪播圖
- assets/card-1.svg 至 card-4.svg：四張 Cards 圖片
- assets/style.css：自訂樣式

本網站使用 Bootstrap 5.3.8 CDN，含自動輪播、四張圖片、四欄 Cards 與指定頁尾資料。

GitHub Pages 發布步驟：
1. 登入 GitHub，新增名為 midterm151 的 Public repository。
2. 將本資料夾內所有檔案（包含 assets 資料夾）上傳至 repository 根目錄。
3. 進入 Settings > Pages。
4. 在 Build and deployment 選擇 Deploy from a branch。
5. Branch 選 main、資料夾選 / (root)，按 Save。
6. 等待 GitHub Pages 部署完成。網址格式為 https://你的GitHub帳號.github.io/midterm151/

注意：請以 GitHub Pages 頁面顯示的實際網址為準。
